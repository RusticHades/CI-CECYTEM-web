document.addEventListener('DOMContentLoaded', function() {
    // Tu código aquí
    document.getElementById('btn1').addEventListener('click', function(){
        console.log("Entró en la función");
        let textos = document.querySelectorAll(".semestres");
        textos.forEach(texto => {
            texto.style.display = 'none';
        });

        let texto1 = document.getElementById('text1');
        texto1.style.display = 'flex';
        texto1.style.flexDirection='column';
    });

    document.getElementById('btn2').addEventListener('click', function(){
        console.log("Entró en la función");
        let textos = document.querySelectorAll(".semestres");
        textos.forEach(texto => {
            texto.style.display = 'none';
        });

        let texto1 = document.getElementById('text2');
        texto1.style.display = 'flex';
        texto1.style.flexDirection='column';
    });

    document.getElementById('btn3').addEventListener('click', function(){
        console.log("Entró en la función");
        let textos = document.querySelectorAll(".semestres");
        textos.forEach(texto => {
            texto.style.display = 'none';
        });

        let texto1 = document.getElementById('text3');
        texto1.style.display = 'flex';
        texto1.style.flexDirection='column';
    });

    document.getElementById('btn4').addEventListener('click', function(){
        console.log("Entró en la función");
        let textos = document.querySelectorAll(".semestres");
        textos.forEach(texto => {
            texto.style.display = 'none';
        });

        let texto1 = document.getElementById('text4');
        texto1.style.display = 'flex';
        texto1.style.flexDirection='column';
    });

    document.getElementById('btn5').addEventListener('click', function(){
        console.log("Entró en la función");
        let textos = document.querySelectorAll(".semestres");
        textos.forEach(texto => {
            texto.style.display = 'none';
        });

        let texto1 = document.getElementById('text5');
        texto1.style.display = 'flex';
        texto1.style.flexDirection='column';
    });

    document.getElementById('btn6').addEventListener('click', function(){
        console.log("Entró en la función");
        let textos = document.querySelectorAll(".semestres");
        textos.forEach(texto => {
            texto.style.display = 'none';
        });

        let texto1 = document.getElementById('text6');
        texto1.style.display = 'flex';
        texto1.style.flexDirection='column';
    });
});



document.addEventListener('DOMContentLoaded', function() {
    // Tu código aquí
    document.getElementById('button1').addEventListener('click', function(){
        console.log("Entró en la función");
        let textos = document.querySelectorAll(".semestres");
        textos.forEach(texto => {
            texto.style.display = 'none';
        });

        let texto1 = document.getElementById('txt1');
        texto1.style.display = 'flex';
        texto1.style.flexDirection='row';
        texto1.style.flexWrap='wrap';
        texto1.style.justifyContent='center';
    });

    document.getElementById('button2').addEventListener('click', function(){
        console.log("Entró en la función");
        let textos = document.querySelectorAll(".semestres");
        textos.forEach(texto => {
            texto.style.display = 'none';
        });

        let texto1 = document.getElementById('txt2');
        texto1.style.display = 'flex';
        texto1.style.flexDirection='row';
        texto1.style.flexWrap='wrap';
        texto1.style.justifyContent='center';
    });

    document.getElementById('button3').addEventListener('click', function(){
        console.log("Entró en la función");
        let textos = document.querySelectorAll(".semestres");
        textos.forEach(texto => {
            texto.style.display = 'none';
        });

        let texto1 = document.getElementById('txt3');
        texto1.style.display = 'flex';
        texto1.style.flexDirection='row';
        texto1.style.flexWrap='wrap';
        texto1.style.justifyContent='center';
    });

    document.getElementById('button4').addEventListener('click', function(){
        console.log("Entró en la función");
        let textos = document.querySelectorAll(".semestres");
        textos.forEach(texto => {
            texto.style.display = 'none';
        });

        let texto1 = document.getElementById('txt4');
        texto1.style.display = 'flex';
        texto1.style.flexDirection='row';
        texto1.style.flexWrap='wrap';
        texto1.style.justifyContent='center';
    });

    document.getElementById('button5').addEventListener('click', function(){
        console.log("Entró en la función");
        let textos = document.querySelectorAll(".semestres");
        textos.forEach(texto => {
            texto.style.display = 'none';
        });

        let texto1 = document.getElementById('txt5');
        texto1.style.display = 'flex';
        texto1.style.flexDirection='row';
        texto1.style.flexWrap='wrap';
        texto1.style.justifyContent='center';
    });

    document.getElementById('button6').addEventListener('click', function(){
        console.log("Entró en la función");
        let textos = document.querySelectorAll(".semestres");
        textos.forEach(texto => {
            texto.style.display = 'none';
        });

        let texto1 = document.getElementById('txt6');
        texto1.style.display = 'flex';
        texto1.style.flexDirection='row';
        texto1.style.flexWrap='wrap';
        texto1.style.justifyContent='center';
    });

   
});