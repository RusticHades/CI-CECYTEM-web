document.addEventListener("DOMContentLoaded", function() {

    document.getElementById('flecha').addEventListener('click', function(){
        let text = document.getElementById('txt');
        let flecha = document.getElementById('flecha');
    
        flecha.style.transform = 'rotate(180deg)';
    
        if(text.style.display === 'none'){
            text.style.display = 'flex';
            text.style.marginTop = '50px';
            text.style.marginBottom = '20px';
            text.style.padding = '0 0px';
        } else {
            setTimeout(function(){ 
                text.style.display = 'none';
                flecha.style.transform = 'rotate(360deg)';
            }, 0); 
        }
    });




    const articles = document.querySelectorAll(".area-1");
    let contador = 1;

    mostrarArticulo(contador);

    document.getElementById('arrow-left').addEventListener('click', function(){
        contador--;
        if (contador < 0) {
            contador = articles.length - 1;
        }
        mostrarArticulo(contador);
    });

    document.getElementById('arrow-right').addEventListener('click', function(){
        contador++;
        if (contador >= articles.length) {
            contador = 0;
        }
        mostrarArticulo(contador);
    });

    function mostrarArticulo(indice) {
        articles.forEach(function(article, index) {
            if (index === indice) {
                article.classList.add('active');
            } else {
                article.classList.remove('active');
            }
        });
    }
});